package com.zen.covid_19news.models

class Premium(
) {
    override fun toString(): String {
        return "Premium()"
    }
}
package com.zen.covid_19news.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.zen.covid_19news.models.DailyReportModel
import com.zen.covid_19news.repo.MainRepo
import com.zen.covid_19news.utils.Resource
import kotlinx.coroutines.launch
import retrofit2.Response

class DailyReportViewModel(val mainRepo: MainRepo) : ViewModel() {

    val dailyReport: MutableLiveData<Resource<DailyReportModel>> = MutableLiveData()
    var dailyReportResponse: DailyReportModel? = null

    fun getDailyReport(date: String) = viewModelScope.launch {
        dailyReport.postValue(Resource.Loading())
        val response = mainRepo.getDailyReports(date)
        dailyReport.postValue(handleDailyReportResponse(response))
    }

    private fun handleDailyReportResponse(response: Response<DailyReportModel>) : Resource<DailyReportModel> {
        if(response.isSuccessful) {
            response.body()?.let { resultResponse ->
                if(dailyReportResponse == null) {
                    dailyReportResponse = resultResponse
                }
                return Resource.Success(dailyReportResponse ?: resultResponse)
            }
        }
        return Resource.Failure(response.message())
    }
}
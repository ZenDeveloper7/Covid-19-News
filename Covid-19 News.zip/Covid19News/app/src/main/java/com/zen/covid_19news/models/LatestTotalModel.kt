package com.zen.covid_19news.models

class LatestTotalModel : ArrayList<LatestTotalModelItem>()
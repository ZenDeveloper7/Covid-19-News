package com.zen.covid_19news.models

data class AllDataItem(
    val Active: Int,
    val Confirmed: Int,
    val Country: String,
    val CountryCode: String,
    val Date: String,
    val Deaths: Int,
    val Lat: String,
    val LocationID: String,
    val Lon: String,
    val Recovered: Int
)
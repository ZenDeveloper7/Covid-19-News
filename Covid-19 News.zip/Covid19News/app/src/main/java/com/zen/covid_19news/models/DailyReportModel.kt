package com.zen.covid_19news.models

class DailyReportModel : ArrayList<DailyReportModelItem>()
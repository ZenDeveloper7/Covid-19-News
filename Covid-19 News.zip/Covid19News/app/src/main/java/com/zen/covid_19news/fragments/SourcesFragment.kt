package com.zen.covid_19news.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.zen.covid_19news.R
import com.zen.covid_19news.adapter.SourceAdapter
import kotlinx.android.synthetic.main.fragment_source.*

class SourcesFragment : Fragment(R.layout.fragment_source) {

    lateinit var sourceAdapter: SourceAdapter
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        sourceAdapter = SourceAdapter()
        sourceRecycler.apply {
            layoutManager = LinearLayoutManager(activity)
            adapter = sourceAdapter
        }

    }
}
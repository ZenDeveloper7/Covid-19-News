package com.zen.covid_19news.utils

object Constants {
    val WORLD_DATA = "WORLD_DATA"
    val APP_NAME = "COVID_19"
}
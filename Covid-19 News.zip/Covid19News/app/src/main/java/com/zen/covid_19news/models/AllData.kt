package com.zen.covid_19news.models

class AllData : ArrayList<AllDataItem>()
package com.zen.covid_19news.models

class DailyReportByCountryModel : ArrayList<DailyReportByCountryModelItem>()
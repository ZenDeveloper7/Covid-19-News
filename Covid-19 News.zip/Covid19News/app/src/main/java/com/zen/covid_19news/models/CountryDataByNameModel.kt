package com.zen.covid_19news.models

class CountryDataByNameModel : ArrayList<CountryDataByNameModelItem>()